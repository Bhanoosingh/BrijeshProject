import java.io.File;
import java.util.UUID;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;







public class product extends HttpServlet {
 String p_name,p_quantity,p_discription,p_category,p_brand,p_image,p_price,p_code,p_purchases,supplier_id;
    boolean isactive;
    Connection con;
    PreparedStatement ps;
boolean isMultipart;
String filepath;
int maxFileSize=50*1024;
int maxMemSize=4*1024;
File file;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //wether request is of multi part or not
  
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       p_code="PRD"+UUID.randomUUID().toString().substring(25).toUpperCase();
        p_name = request.getParameter("p_name");
        p_quantity = request.getParameter("p_quantity");
        p_discription = request.getParameter("p_discription");
        p_brand = request.getParameter("p_brand");
        p_category = request.getParameter("p_category");
        p_image = request.getParameter("p_image");
        p_price=request.getParameter("p_price");
        isactive=Boolean.parseBoolean(request.getParameter("active"));
        p_purchases=request.getParameter("p_purchases");
        supplier_id=request.getParameter("Supplier_id");
        
        try {
            
            
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shop_e_com", "root", "");
            //  ps=con.prepareStatement("insert into person values('"+ username+"','"+password+"','"+phone+"','"+email+"')");
           // ps = con.prepareStatement("insert into product(Pro_Name,code,Pro_quantity,Pro_Discription,Pro_category,Pro_Brand,Pro_image,Pro_price) values(?,?,?,?,?,?,?,?)");
            String sql="insert into product(brand,category_id,code,description,is_active,name,purchases,quantity,product_image,supplier_id,unit_price) "
                    + "values('"+p_brand
                    +"',"+p_category
                    +",'"+p_code
                    +"','"+p_discription
                    +"',"+isactive
                    +",'"+p_name
                    +"',"+p_purchases
                    +","+p_quantity
                    +","+supplier_id
                    +","+p_price+")";
            
            ps = con.prepareStatement("insert into product(brand,category_id,code,description,is_active,name,purchases,quantity,product_image,supplier_id,unit_price) values(?,?,?,?,?,?,?,?,?,?,?)");
            
            ps.setString(1,p_brand );
            ps.setString(2, p_category);
            ps.setString(3,p_code);
            ps.setString(4, p_discription);
            if(isactive){
            ps.setString(5, "1");
            }
            else{
                ps.setString(5, "0");
            }
            ps.setString(6, p_name);
            ps.setString(7, p_purchases);
            ps.setString(8, p_image);
            ps.setString(9,p_quantity);
             ps.setString(10,supplier_id); 
             ps.setString(11,p_price);
         //    ps.setString(11,p_image);
            ps.executeUpdate();
            
            out.println("Category Addded successfully"+sql);

        } catch (Exception e) {
 out.println("Error while inserting data->" + e.getMessage());

        }
        request.setAttribute("code", p_code);
        request.getRequestDispatcher("FileUpload.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
